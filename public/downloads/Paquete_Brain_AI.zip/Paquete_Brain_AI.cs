#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private SuperPowerAbsortions[] cacheSuperPowerAbsortions;
		private SuperPowerBigTrades[] cacheSuperPowerBigTrades;

		
		public SuperPowerAbsortions SuperPowerAbsortions(int minVolume, int reversalTicks, float scaleFactor, float minWidth, float maxWidth, int opacity, bool showLabels, System.Windows.Media.Brush bullishFillColor, System.Windows.Media.Brush bullishOutlineColor, System.Windows.Media.Brush bearishFillColor, System.Windows.Media.Brush bearishOutlineColor, System.Windows.Media.Brush textColor, SimpleFont textFont)
		{
			return SuperPowerAbsortions(Input, minVolume, reversalTicks, scaleFactor, minWidth, maxWidth, opacity, showLabels, bullishFillColor, bullishOutlineColor, bearishFillColor, bearishOutlineColor, textColor, textFont);
		}

		public SuperPowerBigTrades SuperPowerBigTrades(int minVolume, float scaleFactor, float minRadius, float maxRadius, int opacity, bool showLabels, System.Windows.Media.Brush buyFillColor, System.Windows.Media.Brush buyOutlineColor, System.Windows.Media.Brush sellFillColor, System.Windows.Media.Brush sellOutlineColor, System.Windows.Media.Brush textColor, SimpleFont textFont)
		{
			return SuperPowerBigTrades(Input, minVolume, scaleFactor, minRadius, maxRadius, opacity, showLabels, buyFillColor, buyOutlineColor, sellFillColor, sellOutlineColor, textColor, textFont);
		}


		
		public SuperPowerAbsortions SuperPowerAbsortions(ISeries<double> input, int minVolume, int reversalTicks, float scaleFactor, float minWidth, float maxWidth, int opacity, bool showLabels, System.Windows.Media.Brush bullishFillColor, System.Windows.Media.Brush bullishOutlineColor, System.Windows.Media.Brush bearishFillColor, System.Windows.Media.Brush bearishOutlineColor, System.Windows.Media.Brush textColor, SimpleFont textFont)
		{
			if (cacheSuperPowerAbsortions != null)
				for (int idx = 0; idx < cacheSuperPowerAbsortions.Length; idx++)
					if (cacheSuperPowerAbsortions[idx].MinVolume == minVolume && cacheSuperPowerAbsortions[idx].ReversalTicks == reversalTicks && cacheSuperPowerAbsortions[idx].ScaleFactor == scaleFactor && cacheSuperPowerAbsortions[idx].MinWidth == minWidth && cacheSuperPowerAbsortions[idx].MaxWidth == maxWidth && cacheSuperPowerAbsortions[idx].Opacity == opacity && cacheSuperPowerAbsortions[idx].ShowLabels == showLabels && cacheSuperPowerAbsortions[idx].BullishFillColor == bullishFillColor && cacheSuperPowerAbsortions[idx].BullishOutlineColor == bullishOutlineColor && cacheSuperPowerAbsortions[idx].BearishFillColor == bearishFillColor && cacheSuperPowerAbsortions[idx].BearishOutlineColor == bearishOutlineColor && cacheSuperPowerAbsortions[idx].TextColor == textColor && cacheSuperPowerAbsortions[idx].TextFont == textFont && cacheSuperPowerAbsortions[idx].EqualsInput(input))
						return cacheSuperPowerAbsortions[idx];
			return CacheIndicator<SuperPowerAbsortions>(new SuperPowerAbsortions(){ MinVolume = minVolume, ReversalTicks = reversalTicks, ScaleFactor = scaleFactor, MinWidth = minWidth, MaxWidth = maxWidth, Opacity = opacity, ShowLabels = showLabels, BullishFillColor = bullishFillColor, BullishOutlineColor = bullishOutlineColor, BearishFillColor = bearishFillColor, BearishOutlineColor = bearishOutlineColor, TextColor = textColor, TextFont = textFont }, input, ref cacheSuperPowerAbsortions);
		}

		public SuperPowerBigTrades SuperPowerBigTrades(ISeries<double> input, int minVolume, float scaleFactor, float minRadius, float maxRadius, int opacity, bool showLabels, System.Windows.Media.Brush buyFillColor, System.Windows.Media.Brush buyOutlineColor, System.Windows.Media.Brush sellFillColor, System.Windows.Media.Brush sellOutlineColor, System.Windows.Media.Brush textColor, SimpleFont textFont)
		{
			if (cacheSuperPowerBigTrades != null)
				for (int idx = 0; idx < cacheSuperPowerBigTrades.Length; idx++)
					if (cacheSuperPowerBigTrades[idx].MinVolume == minVolume && cacheSuperPowerBigTrades[idx].ScaleFactor == scaleFactor && cacheSuperPowerBigTrades[idx].MinRadius == minRadius && cacheSuperPowerBigTrades[idx].MaxRadius == maxRadius && cacheSuperPowerBigTrades[idx].Opacity == opacity && cacheSuperPowerBigTrades[idx].ShowLabels == showLabels && cacheSuperPowerBigTrades[idx].BuyFillColor == buyFillColor && cacheSuperPowerBigTrades[idx].BuyOutlineColor == buyOutlineColor && cacheSuperPowerBigTrades[idx].SellFillColor == sellFillColor && cacheSuperPowerBigTrades[idx].SellOutlineColor == sellOutlineColor && cacheSuperPowerBigTrades[idx].TextColor == textColor && cacheSuperPowerBigTrades[idx].TextFont == textFont && cacheSuperPowerBigTrades[idx].EqualsInput(input))
						return cacheSuperPowerBigTrades[idx];
			return CacheIndicator<SuperPowerBigTrades>(new SuperPowerBigTrades(){ MinVolume = minVolume, ScaleFactor = scaleFactor, MinRadius = minRadius, MaxRadius = maxRadius, Opacity = opacity, ShowLabels = showLabels, BuyFillColor = buyFillColor, BuyOutlineColor = buyOutlineColor, SellFillColor = sellFillColor, SellOutlineColor = sellOutlineColor, TextColor = textColor, TextFont = textFont }, input, ref cacheSuperPowerBigTrades);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.SuperPowerAbsortions SuperPowerAbsortions(int minVolume, int reversalTicks, float scaleFactor, float minWidth, float maxWidth, int opacity, bool showLabels, System.Windows.Media.Brush bullishFillColor, System.Windows.Media.Brush bullishOutlineColor, System.Windows.Media.Brush bearishFillColor, System.Windows.Media.Brush bearishOutlineColor, System.Windows.Media.Brush textColor, SimpleFont textFont)
		{
			return indicator.SuperPowerAbsortions(Input, minVolume, reversalTicks, scaleFactor, minWidth, maxWidth, opacity, showLabels, bullishFillColor, bullishOutlineColor, bearishFillColor, bearishOutlineColor, textColor, textFont);
		}

		public Indicators.SuperPowerBigTrades SuperPowerBigTrades(int minVolume, float scaleFactor, float minRadius, float maxRadius, int opacity, bool showLabels, System.Windows.Media.Brush buyFillColor, System.Windows.Media.Brush buyOutlineColor, System.Windows.Media.Brush sellFillColor, System.Windows.Media.Brush sellOutlineColor, System.Windows.Media.Brush textColor, SimpleFont textFont)
		{
			return indicator.SuperPowerBigTrades(Input, minVolume, scaleFactor, minRadius, maxRadius, opacity, showLabels, buyFillColor, buyOutlineColor, sellFillColor, sellOutlineColor, textColor, textFont);
		}


		
		public Indicators.SuperPowerAbsortions SuperPowerAbsortions(ISeries<double> input , int minVolume, int reversalTicks, float scaleFactor, float minWidth, float maxWidth, int opacity, bool showLabels, System.Windows.Media.Brush bullishFillColor, System.Windows.Media.Brush bullishOutlineColor, System.Windows.Media.Brush bearishFillColor, System.Windows.Media.Brush bearishOutlineColor, System.Windows.Media.Brush textColor, SimpleFont textFont)
		{
			return indicator.SuperPowerAbsortions(input, minVolume, reversalTicks, scaleFactor, minWidth, maxWidth, opacity, showLabels, bullishFillColor, bullishOutlineColor, bearishFillColor, bearishOutlineColor, textColor, textFont);
		}

		public Indicators.SuperPowerBigTrades SuperPowerBigTrades(ISeries<double> input , int minVolume, float scaleFactor, float minRadius, float maxRadius, int opacity, bool showLabels, System.Windows.Media.Brush buyFillColor, System.Windows.Media.Brush buyOutlineColor, System.Windows.Media.Brush sellFillColor, System.Windows.Media.Brush sellOutlineColor, System.Windows.Media.Brush textColor, SimpleFont textFont)
		{
			return indicator.SuperPowerBigTrades(input, minVolume, scaleFactor, minRadius, maxRadius, opacity, showLabels, buyFillColor, buyOutlineColor, sellFillColor, sellOutlineColor, textColor, textFont);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.SuperPowerAbsortions SuperPowerAbsortions(int minVolume, int reversalTicks, float scaleFactor, float minWidth, float maxWidth, int opacity, bool showLabels, System.Windows.Media.Brush bullishFillColor, System.Windows.Media.Brush bullishOutlineColor, System.Windows.Media.Brush bearishFillColor, System.Windows.Media.Brush bearishOutlineColor, System.Windows.Media.Brush textColor, SimpleFont textFont)
		{
			return indicator.SuperPowerAbsortions(Input, minVolume, reversalTicks, scaleFactor, minWidth, maxWidth, opacity, showLabels, bullishFillColor, bullishOutlineColor, bearishFillColor, bearishOutlineColor, textColor, textFont);
		}

		public Indicators.SuperPowerBigTrades SuperPowerBigTrades(int minVolume, float scaleFactor, float minRadius, float maxRadius, int opacity, bool showLabels, System.Windows.Media.Brush buyFillColor, System.Windows.Media.Brush buyOutlineColor, System.Windows.Media.Brush sellFillColor, System.Windows.Media.Brush sellOutlineColor, System.Windows.Media.Brush textColor, SimpleFont textFont)
		{
			return indicator.SuperPowerBigTrades(Input, minVolume, scaleFactor, minRadius, maxRadius, opacity, showLabels, buyFillColor, buyOutlineColor, sellFillColor, sellOutlineColor, textColor, textFont);
		}


		
		public Indicators.SuperPowerAbsortions SuperPowerAbsortions(ISeries<double> input , int minVolume, int reversalTicks, float scaleFactor, float minWidth, float maxWidth, int opacity, bool showLabels, System.Windows.Media.Brush bullishFillColor, System.Windows.Media.Brush bullishOutlineColor, System.Windows.Media.Brush bearishFillColor, System.Windows.Media.Brush bearishOutlineColor, System.Windows.Media.Brush textColor, SimpleFont textFont)
		{
			return indicator.SuperPowerAbsortions(input, minVolume, reversalTicks, scaleFactor, minWidth, maxWidth, opacity, showLabels, bullishFillColor, bullishOutlineColor, bearishFillColor, bearishOutlineColor, textColor, textFont);
		}

		public Indicators.SuperPowerBigTrades SuperPowerBigTrades(ISeries<double> input , int minVolume, float scaleFactor, float minRadius, float maxRadius, int opacity, bool showLabels, System.Windows.Media.Brush buyFillColor, System.Windows.Media.Brush buyOutlineColor, System.Windows.Media.Brush sellFillColor, System.Windows.Media.Brush sellOutlineColor, System.Windows.Media.Brush textColor, SimpleFont textFont)
		{
			return indicator.SuperPowerBigTrades(input, minVolume, scaleFactor, minRadius, maxRadius, opacity, showLabels, buyFillColor, buyOutlineColor, sellFillColor, sellOutlineColor, textColor, textFont);
		}

	}
}

#endregion
